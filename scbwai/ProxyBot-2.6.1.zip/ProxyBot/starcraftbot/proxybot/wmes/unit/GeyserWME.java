package starcraftbot.proxybot.wmes.unit;
/**
 * Represents a geyser.
 */
public class GeyserWME extends UnitWME {

}