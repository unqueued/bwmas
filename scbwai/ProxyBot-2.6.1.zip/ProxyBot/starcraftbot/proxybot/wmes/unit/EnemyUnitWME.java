package starcraftbot.proxybot.wmes.unit;
/**
 * Represents an enemy unit.
 */
public class EnemyUnitWME extends UnitWME {

}
