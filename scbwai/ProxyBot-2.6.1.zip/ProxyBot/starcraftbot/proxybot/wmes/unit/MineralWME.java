package starcraftbot.proxybot.wmes.unit;
/**
 * Represents a mineral patch.
 */
public class MineralWME extends UnitWME {

}
