package starcraftbot.proxybot.wmes.unit;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import starcraftbot.proxybot.wmes.WME;
/**
 * Represents a bot-controlled unit.
 */
public class PlayerUnitWME extends UnitWME {
	
}