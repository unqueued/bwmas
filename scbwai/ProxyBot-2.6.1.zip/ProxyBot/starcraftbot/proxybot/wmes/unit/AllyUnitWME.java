package starcraftbot.proxybot.wmes.unit;
/**
 * Represents an allied unit.
 */
public class AllyUnitWME extends UnitWME {

}
