package starcraftbot.proxybot.command;

public interface CommandListener {

	public void event(Command command);
}
