#include <BWSAL.h>
Arbitrator::Arbitrator<BWAPI::Unit*,double>* TheArbitrator = NULL;